function [MAPE,X0F] = ANDGM( w,X0 )
m=4;
n=numel(X0);
w;           %��ʾ���� X1(k)=w*X1(k-1)+(1-w)*X0(k)
X1(1)=X0(1);
for i=2:n
    X1(i)=X1(i-1)+X0(i);
end
Xw(1)=X0(1);
for i=2:n
    Xw(i)=w*X1(i-1)+(1-w)*X0(i);
end
for i=1:n-1
    B(i,1)=Xw(i);
    B(i,2)=i;
    B(i,3)=1;
    Y(i,1)=Xw(i+1);
end
P=(B'*B)\B'*Y;
a=P(1);
b=P(2);
c=P(3);
XwF(1)=Xw(1);
for i=2:n+m
    XwF(i)=a*XwF(i-1)+b*(i-1)+c;
end
X0F(1)=X0(1);
for i=2:n+m
    tmp=0;
    for j=1:i-1
        tmp=tmp+X0F(j);
    end
  X0F(i)=(XwF(i)-w*tmp)/(1-w);
end
for i=2:n
    mape(i)=abs(X0F(i)-X0(i))/X0(i);
end
MAPE=mean(mape(2:n));
end
